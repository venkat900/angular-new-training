import { Directive, OnInit, ElementRef, Renderer2, HostListener, HostBinding, Input } from '@angular/core';

@Directive({
  selector: '[appBetterHilight]'
})
export class BetterHilightDirective implements OnInit{
  @Input() defaultColor:string='pink';
   hilightColor:string='red';
  @HostBinding('style.backgroundColor') backgroundColor:string;

  constructor(private elementRef: ElementRef,
              private renderer: Renderer2) { }

  ngOnInit(){
    this.backgroundColor = this.defaultColor;
    //this.renderer.setStyle(
      //this.elementRef.nativeElement,'background-color','orange');
  }

  @HostListener('mouseover')mouseover(eventData: Event){
    //this.renderer.setStyle(
     // this.elementRef.nativeElement,'background-color','yellow'
    //)
    this.backgroundColor = this.hilightColor;
  }

  @HostListener('mouseleave')mouseleave(eventData: Event){
    //this.renderer.setStyle(
      //this.elementRef.nativeElement,'background-color','purple'
    //)
    this.backgroundColor = this.defaultColor;
  }
}
