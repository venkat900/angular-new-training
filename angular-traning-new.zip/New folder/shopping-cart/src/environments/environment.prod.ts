export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyCSUWRrWkR4Q6E2YR2AzF-HIuMudx8EBOI',
    authDomain: 'ng-http-module-88476.firebaseapp.com',
    databaseURL: 'https://ng-http-module-88476.firebaseio.com',
    projectId: 'ng-http-module-88476',
    storageBucket: 'ng-http-module-88476.appspot.com',
    messagingSenderId: '172639357628'
  }
};
