import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shopping-form',
  templateUrl: './shopping-form.component.html',
  styleUrls: ['./shopping-form.component.css']
})
export class ShoppingFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
