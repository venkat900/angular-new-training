export class Order {
    pid: number;
    quantity: number;
    totalPrice: number;
    orderDate: Date;
}