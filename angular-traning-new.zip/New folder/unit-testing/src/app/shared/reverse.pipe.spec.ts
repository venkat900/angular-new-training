import { ReversePipe } from './reverse.pipe';

describe('ReversePipe', () => {
  let reversePipe: ReversePipe;
  beforeEach(()=> {
    reversePipe = new ReversePipe();
  })
  it('create an instance', () => {
    //const pipe = new ReversePipe();
    expect(reversePipe).toBeTruthy();   // checking object is created or not
  });
  it('should reverse the inputs',
  () => {
    //const pipe = new ReversePipe();
    expect(reversePipe.transform('hello')).toEqual('olleh');
  })
});
