import { Injectable } from '@angular/core';
import { resolve, reject } from 'q';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor() { }

  getDetails() {
    const result = new Promise(
      (resolve,reject) => {
        setTimeout(()=>{        //()=>{} -> call back method
          resolve('Data'); // final data
        },2000)
      }
      
      );
      return result;
  }
}
