import { OnInit } from '@angular/core';
import { EmployeeService } from './employee.service';

export class EmployeeComponent implements OnInit {
    employee: any[] = [];
    message: '';

    constructor(private service: EmployeeService){}

    ngOnInit(){
      this.service.getAllEmp()
      .subscribe(
          (eList) => {
              this.employee = <any[]>eList;
          }
      );
    }
    add() {
        const emp = {ename: '...'};
        this.service.addEmp(emp)
        .subscribe(
            res => this.employee.push(res),
            err => this.message = err
        );
    }
    delete(empId) {
        if(confirm('Are you sure?')){
            this.service.deleteEmp(empId).subscribe();
            
        }
    }
}