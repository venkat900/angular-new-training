import { EventEmitter, Output } from '@angular/core';

export class VoteComponent {
    totalVotes = 501;
    @Output() voteChanged = new EventEmitter();
    upVote() {
        this.totalVotes++;
        this.voteChanged.emit(this.totalVotes);
    }
}