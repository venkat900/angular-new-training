import {VoteComponent} from './vote.component';

describe('VoteComponent', () => {
let component: VoteComponent;
beforeEach(() => {
    component = new VoteComponent();
});
it('should raise voteChanged event when call upVote()',
      () => {
          let totalVotes = 0;
          component.voteChanged.subscribe(
              (voteCount) => {
                  totalVotes = voteCount;
              }
          );
          component.upVote();
          expect(totalVotes).toBe(502);
          //expect(totalVotes).toBeNull();
          expect(totalVotes).not.toBeNull();
      })
})