export function getCurrency() {
return [
    'INR','USD','EUR','AUD'
];
}