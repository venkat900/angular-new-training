export function greet(name){
    return 'Welcome Mr/Ms '+name;
}