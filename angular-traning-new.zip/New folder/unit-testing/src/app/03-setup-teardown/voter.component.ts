export class VoterComponent {
    totalVotes = 0;
    upVote(){
        this.totalVotes++;
    }
    downVote(){
        this.totalVotes--;
    }
}