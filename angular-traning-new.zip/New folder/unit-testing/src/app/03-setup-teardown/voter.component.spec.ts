import {VoterComponent} from './voter.component';

describe('VoterComponent', () => {
   let component: VoterComponent;
   beforeEach(()=> {
       component = new VoterComponent();           //arrange
   })
   it('should increment total vote when call upVote()',() => {
    component.upVote();
    expect(component.totalVotes).toBe(1);
   });
   it('should decrement total vote when call downVote()',() => {
     component.downVote();
     expect(component.totalVotes).toBe(-1);
});
});