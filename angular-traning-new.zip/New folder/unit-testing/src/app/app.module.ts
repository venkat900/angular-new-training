import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { ReversePipe } from './shared/reverse.pipe';
import { UserComponent } from './user/user.component';
import { AboutComponent } from './about/about.component';
import { UserListComponent } from './user-list/user-list.component';
import { HomeComponent } from './home/home.component';
import { UsersComponent } from './users/users.component';

const routes: Routes = [
  {path:'', component: HomeComponent},
  {path:'about', component: AboutComponent},
  {path:'user', children: [
    {path:'', redirectTo:'list',pathMatch: 'full'},
    {path:'list',component: UserListComponent, children:[
      {path:'detail/:name', component: UsersComponent}
    ]}
  ]}
]

@NgModule({
  declarations: [
    AppComponent,
    ReversePipe,
    UserComponent,
    AboutComponent,
    UserListComponent,
    HomeComponent,
    UsersComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
