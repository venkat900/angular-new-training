import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';

import { UserComponent } from './user.component';
import { UserService } from './user.service';
import { DataService } from '../shared/data.service';

describe('UserComponent', () => {
  let component: UserComponent;
  let fixture: ComponentFixture<UserComponent>;
  let userService: UserService;
  let dataService: DataService;

  beforeEach(async(() => {             // 1st time it will be called
    TestBed.configureTestingModule({     
      declarations: [ UserComponent ]   // by default this beforeEach will be called asynchronously
    })                                  // and create the TestBed Object
    .compileComponents();
  }));

  beforeEach(() => {                          // 2nd time it will be called
    fixture = TestBed.createComponent(UserComponent); // create fixture
    component = fixture.componentInstance; // create component instance
    //fixture.detectChanges(); // detect any changes
  });

  it('should create the user', () => {
    expect(component).toBeTruthy();
  });

  it('should use the user name from the service', ()=>{
    userService = fixture.debugElement.injector.get(UserService);
    fixture.detectChanges();
    expect(userService.user.name).toEqual(component.username.name);
  });

  it('should display the username if user is logged in',()=>{
    component.isLoggedIn = true;
    fixture.detectChanges();
    let compiled = fixture.debugElement.nativeElement; // create instance of template
    expect(compiled.querySelector('p')
    .textContent).toContain(component.username.name);
  });

  it('should not display the user name if user is not logged in',
  () => {
    component.isLoggedIn = false;
    fixture.detectChanges();
    let compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('p').
    textContent).not.toContain(component.username.name);
  });

  it('should not fetch data if not called asynchronously',
  () => {
    dataService = fixture.debugElement.injector.get(DataService); //DataService object is created
    let spy = spyOn(dataService,"getDetails").and.returnValue(Promise.resolve('Data'));
    fixture.detectChanges();
    expect(component.mydata).toBe(undefined);
  });

  it('should fetch data if called asynchronously - async',
  () => {
    dataService = fixture.debugElement.injector.get(DataService);
    let spy = spyOn(dataService,"getDetails").and.returnValue(Promise.resolve('Data'));
    fixture.detectChanges();
    fixture.whenStable().then(
      () => {
        expect(component.mydata).toBe('Data');
      }
    )
  });

  it('should fetch data if called asynchronously - fakeasync',
  fakeAsync(() => {
    dataService = fixture.debugElement.injector.get(DataService);
    let spy = spyOn(dataService,"getDetails").and.returnValue(Promise.resolve('Data'));
    fixture.detectChanges();
    tick();
    expect(component.mydata).toBe('Data');
  }));
});
