import {TodoFormComponent} from './todo-form.component';
import {FormBuilder} from '@angular/forms';

describe('TodoFormComponent', () => {
  let component: TodoFormComponent;
  beforeEach(() => {
      component = new TodoFormComponent(new FormBuilder());
  });
  it('should create a form with name control', () => {
       expect(component.form.contains('name')).toBeTruthy();
  });
  it('should make the control is required - false case', () =>{
      const control = component.form.get('name');
      control.setValue('');
      expect(control.valid).toBeFalsy();
  });
  it('should make the control is required - true case', () =>{
    const control = component.form.get('name');
    control.setValue('angular');
    expect(control.valid).toBeTruthy();
});
  it('should create a form with email control', () => {
    expect(component.form.contains('email')).toBeTruthy();
  });

})