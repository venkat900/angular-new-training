import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams, HttpRequest } from '@angular/common/http'
import { ServersService } from '../servers/servers.service';
import { AuthService } from '../auth/auth.service';
import { from } from 'rxjs';
import { Servers } from '../servers/servers.model';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class DataStorageService {
  constructor(private http: HttpClient,
    private serverService: ServersService,
    private authService: AuthService) { }

  storeServer() {
   // const myToken = this.authService.getToken();
    //const myHeader = new HttpHeaders().set('authorization','done');
    //const myParam = new HttpParams().set('auth','myToken');
   // return this.http.put('https://ng-http-module-88476.firebaseio.com/servers.json?auth='
    //  , this.serverService.getServers()
    //  , {
     //   observe: 'body',
    //    headers: new HttpHeaders().set('authorization','done'),
     //   params: new HttpParams().set('auth','myToken')
    //  }
    //);
    const req = new HttpRequest('PUT','https://ng-http-module-88476.firebaseio.com/servers.json',
    this.serverService.getServers(), {reportProgress: true});
    return this.http.request(req);
  }
  getServers() {
    const myToken = this.authService.getToken();
    this.http.get<Servers[]>('https://ng-http-module-88476.firebaseio.com/servers.json')
      .pipe(map(
        (servers) => {
          console.log(servers);
          return servers;
        }
      ))
      .subscribe(
        (servers: Servers[]) => {
          this.serverService.setServers(servers);
        }
      )
  }
}
