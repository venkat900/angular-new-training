import { Component, OnInit } from '@angular/core';
import * as firebase from 'firebase';
import { AuthService } from './auth/auth.service';
import { DataStorageService } from './shared/data-storage.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  constructor(public authService: AuthService,
              public dataService: DataStorageService){

  }
  ngOnInit(){
   firebase.initializeApp({
    apiKey: 'AIzaSyCSUWRrWkR4Q6E2YR2AzF-HIuMudx8EBOI',
    authDomain: 'ng-http-module-88476.firebaseapp.com'
   });
  }
  onSaveData(){
    this.dataService.storeServer()
    .subscribe(
      (response) => console.log(response),
      error => console.log(error)
    );
  }
  onFetchData(){
    this.dataService.getServers();
  }
  onLogout(){
    this.authService.logout();
  }
}
