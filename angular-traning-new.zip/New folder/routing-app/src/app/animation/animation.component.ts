import { Component, OnInit } from '@angular/core';
import { trigger, state, style, transition, animate, keyframes, group } from '@angular/animations';

@Component({
  selector: 'app-animation',
  templateUrl: './animation.component.html',
  styleUrls: ['./animation.component.css'],
  animations: [
    trigger('divState',[
      state('normal',style({
        backgroundColor: 'red',
        transform: 'translateX(0)'
      })),
      state('hilighted',style({
        backgroundColor: 'blue',
        transform: 'translateX(100px)'
      })),
      //transition('normal => hilighted',animate(1000)),
      //transition('hilighted => normal',animate(2000))
      transition('normal <=> hilighted',animate(2000))
    ]),
     trigger('wildState',[
         state('normal',style({
           backgroundColor: 'green',
           transform: 'translateX(0) scale(1)'
         })),
         state('hilighted',style({
          backgroundColor: 'yellow',
          transform: 'translateX(100px) scale(1)'
        })),
        state('shrunken',style({
          backgroundColor: 'orange',
          transform: 'translateX(0) scale(0.5)'
        })),
        transition('normal <=> hilighted',animate(2000)),
        //transition('shrunken <=> normal', animate(1000)),
        //transition('shrunken <=> hilighted', animate(1000)),
        transition('shrunken <=> *',[
          style({
            backgroundColor: 'pink',
          }),
          animate(2000,style({
            borderRadius: '50px'
          })),
          animate(1000)
        ])
     ]),
     trigger('list1',[
       state('in',style({
         opacity: 1,
         transform: 'translateX(0)'
       })),
       transition('void => *',[
         style({
          opacity: 0,
          transform: 'translateX(-100px)'
         }),
         animate(1000)
       ]),
       transition('* => void',[
         animate(1500),
         style({
          transform: 'translateX(100px)',
          opacity: 0
         })
       ])
     ]),
     trigger('list2',[
       state('in',style({
        opacity: 1,
        transform: 'translateX(0)'
       })),
       transition('void => *',[
         animate(2000, keyframes([
           style({
             transform: 'translateX(-100px)',
             opacity: 0,
             offset: 0
           }),
           style({
            transform: 'translateX(-50px)',
            opacity: 0.5,
            offset: 0.3
          }),
          style({
            transform: 'translateX(-20px)',
            opacity: 1,
            offset: 0.8
          }),
          style({
            transform: 'translateX(0px)',
            opacity: 1,
            offset: 1
          })
         ]))
       ]),
       transition('* => void',[
         group([
          animate(1200, style({
            color: 'red'
          })),
          animate(2000, style({
           transform: 'translateX(100px)',
             opacity: 1
          }))
         ])
         
       ])
     ])
  ]
})
export class AnimationComponent implements OnInit {
items: string[] = [
  'Angular','React','Observable'
];
state = 'normal';
wildState = 'normal';
  constructor() { }

  ngOnInit() {
  }
  onAdd(element:string){
    this.items.push(element);
  }
  onAnimate(){
    this.state === 'normal'?this.state = 
                'hilighted':this.state = 'normal';
    this.wildState === 'normal'?this.wildState =
                'hilighted':this.wildState = 'normal';
  }
  onShrink(){
    this.wildState = 'shrunken';
  }
  animationStarted(event){
      console.log('Animate Started:'+event);
      
  }
  animationEnded(event){
    console.log('Animate Ended:'+event);
    
}
onDelete(item){
this.items.splice(this.items.indexOf(item),1);
}

}
