import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { UserComponent } from './users/user/user.component';
import { ServersComponent } from './servers/servers.component';
import { ServerComponent } from './servers/server/server.component';
import { EditServerComponent } from './servers/edit-server/edit-server.component';
import { UsersComponent } from './users/users.component';
import {FormsModule} from '@angular/forms';
//import {Routes, RouterModule} from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { SigninComponent } from './auth/signin/signin.component';
import { SignupComponent } from './auth/signup/signup.component';
import { DropdownDirective } from './shared/dropdown.directive';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthService } from './auth/auth.service';
import { AuthGuard } from './auth/auth.guard';
import { ServersService } from './servers/servers.service';
import { DataStorageService } from './shared/data-storage.service';
import { AuthInterceptor } from './shared/auth.interceptor';
import { AnimationComponent } from './animation/animation.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    UserComponent,
    ServersComponent,
    ServerComponent,
    EditServerComponent,
    UsersComponent,
    SigninComponent,
    SignupComponent,
    DropdownDirective,
    AnimationComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule
  ],
  providers: [AuthService,
              AuthGuard,
              ServersService,
              DataStorageService,
    {provide: HTTP_INTERCEPTORS,useClass:AuthInterceptor,multi:true}
            ],
  bootstrap: [AppComponent]
})
export class AppModule { }
