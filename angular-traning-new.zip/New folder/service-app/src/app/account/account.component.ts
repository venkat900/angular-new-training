import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { LoggingService } from '../logging.service';
import { AccountService } from '../account.service';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css'],
  providers: [LoggingService,AccountService]
})
export class AccountComponent implements OnInit {
  @Input() account: {name: string, status: string}
  @Input() id: number;
  //@Output() statusChanged = new EventEmitter<{id: number,newStatus: string}>();
  constructor(private logService: LoggingService,
               private accountService: AccountService) { }

  ngOnInit() {
  }
  onSetTo(status: string){
    /* this.statusChanged.emit({
      id: this.id,
      newStatus: status
    }); */
    //console.log('A Server status changed, new status: '+status);
    this.accountService.updateStatus(this.id,status);
    //this.logService.logStatusChanged(status);
    this.accountService.statusUpdated.emit(status);

  }
}
