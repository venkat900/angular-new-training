import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CounterService {

  activeToInactiveCount =0;
  inActiveToActiveCount =0;
  incrementActiveToInactive() {
    this.activeToInactiveCount++;
    console.log('Active to Inactive: '+this.activeToInactiveCount);
  }

  incrementInActiveToActive() {
    this.inActiveToActiveCount++;
    console.log('InActive to Active: '+this.inActiveToActiveCount);
  }

  constructor() { }
}
